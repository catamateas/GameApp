export const variables={
    API_URL:"http://localhost:58062/api/",
    PHOTO_URL:"http://localhost:3000/Photos/" //de modificat ca sa fie ok, dupa ce ne da alex backendu
}