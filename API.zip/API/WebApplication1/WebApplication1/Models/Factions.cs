﻿namespace WebApplication1.Models
{
    public class Factions
    {
        public int FactionId { get; set; }
        public string FactionName { get; set; }
        public int MemberCount { get; set; }
        public int RequiredLevel { get; set; }
    }
}
