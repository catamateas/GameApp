﻿namespace WebApplication1.Models
{
    public class FactionMembers
    {
        public int FactionMemberId { get; set; }
        public int FactionId { get; set; }
        public int UserId { get; set; }
        public int Rank { get; set; }
    }
}
