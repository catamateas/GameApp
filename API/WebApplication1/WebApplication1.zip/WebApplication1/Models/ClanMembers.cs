﻿namespace WebApplication1.Models
{
    public class ClanMembers
    {
        public int ClanMemeberID { get; set; }
        public int ClanId { get; set; }
        public int UserId { get; set; }
        public int Rank { get; set; }
    }
}
