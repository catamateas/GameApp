﻿namespace WebApplication1.Models
{
    public class Clans
    {
        public int ClanId { get; set; }
        public string ClanName { get; set; }
        public int MemberCount { get; set; }

    }
}
