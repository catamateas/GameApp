﻿namespace WebApplication1.Models
{
    public class Friends
    {
        public int FriendId { get; set; }
        public int UserId { get; set; }
        public int FriendUserId { get; set; }
    }
}
